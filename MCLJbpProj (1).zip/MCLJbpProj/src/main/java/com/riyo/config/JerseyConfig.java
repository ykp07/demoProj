package com.riyo.config;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;

import com.riyo.endpoints.*;

@Configuration
public class JerseyConfig extends ResourceConfig
{
	public JerseyConfig() 
	{
		register(MyDataExchanger.class);
    }

}