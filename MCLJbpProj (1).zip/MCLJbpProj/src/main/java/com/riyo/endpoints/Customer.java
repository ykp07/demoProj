package com.riyo.endpoints;

public class Customer
{
	private String plant = null;
	private String distt = null;
	private String division_id = null;
	private String division_name = null;	
	private String dc_code = null;
	private String dc_name = null;
	private String feeder_id = null;
	private String feedername = null;
	private String dtr_code = null;
	private String zdtr_name = null;
	private String zconsumer_no = null;
	private String consumername = null;
	private String zaddress1 = null;
	private String zmobileno = null;
	private String zmtr_avail = null;
	private String zmtr_no= null;
	private String zmtrdesc = null;
	private String call_bell_loc = null;
	private String zmtr_type = null;
	private String manufacturename = null;
	private String zmanyear = null;
	private String zmtr_box = null;
	private String zmtr_seal = null;
	private String meter_function = null;
	private String zcurr_reading = null;
	private String srv_cable_type = null;
	private String zsrv_status = null;
	private String zsrv_type_loc = null;
	private String metershiftreq = null;
	private String zaddcable = null;
	private String zunit = null;
	private String zsrv_cable_lngh = null;
	private String jointavailstatus = null;
	private String empname = null;
	private String zentryby = null;
	private String zentrydate = null;
	private String zentrytime = null;
	private String zlatitude = null;
	private String zlongitude = null;
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getDistt() {
		return distt;
	}
	public void setDistt(String distt) {
		this.distt = distt;
	}
	public String getDivision_id() {
		return division_id;
	}
	public void setDivision_id(String division_id) {
		this.division_id = division_id;
	}
	public String getDivision_name() {
		return division_name;
	}
	public void setDivision_name(String division_name) {
		this.division_name = division_name;
	}
	public String getDc_code() {
		return dc_code;
	}
	public void setDc_code(String dc_code) {
		this.dc_code = dc_code;
	}
	public String getDc_name() {
		return dc_name;
	}
	public void setDc_name(String dc_name) {
		this.dc_name = dc_name;
	}
	public String getFeeder_id() {
		return feeder_id;
	}
	public void setFeeder_id(String feeder_id) {
		this.feeder_id = feeder_id;
	}
	public String getFeedername() {
		return feedername;
	}
	public void setFeedername(String feedername) {
		this.feedername = feedername;
	}
	public String getDtr_code() {
		return dtr_code;
	}
	public void setDtr_code(String dtr_code) {
		this.dtr_code = dtr_code;
	}
	public String getZdtr_name() {
		return zdtr_name;
	}
	public void setZdtr_name(String zdtr_name) {
		this.zdtr_name = zdtr_name;
	}
	public String getZconsumer_no() {
		return zconsumer_no;
	}
	public void setZconsumer_no(String zconsumer_no) {
		this.zconsumer_no = zconsumer_no;
	}
	public String getConsumername() {
		return consumername;
	}
	public void setConsumername(String consumername) {
		this.consumername = consumername;
	}
	public String getZaddress1() {
		return zaddress1;
	}
	public void setZaddress1(String zaddress1) {
		this.zaddress1 = zaddress1;
	}
	public String getZmobileno() {
		return zmobileno;
	}
	public void setZmobileno(String zmobileno) {
		this.zmobileno = zmobileno;
	}
	public String getZmtr_avail() {
		return zmtr_avail;
	}
	public void setZmtr_avail(String zmtr_avail) {
		this.zmtr_avail = zmtr_avail;
	}
	public String getZmtr_no() {
		return zmtr_no;
	}
	public void setZmtr_no(String zmtr_no) {
		this.zmtr_no = zmtr_no;
	}
	public String getZmtrdesc() {
		return zmtrdesc;
	}
	public void setZmtrdesc(String zmtrdesc) {
		this.zmtrdesc = zmtrdesc;
	}
	public String getCall_bell_loc() {
		return call_bell_loc;
	}
	public void setCall_bell_loc(String call_bell_loc) {
		this.call_bell_loc = call_bell_loc;
	}
	public String getZmtr_type() {
		return zmtr_type;
	}
	public void setZmtr_type(String zmtr_type) {
		this.zmtr_type = zmtr_type;
	}
	public String getManufacturename() {
		return manufacturename;
	}
	public void setManufacturename(String manufacturename) {
		this.manufacturename = manufacturename;
	}
	public String getZmanyear() {
		return zmanyear;
	}
	public void setZmanyear(String zmanyear) {
		this.zmanyear = zmanyear;
	}
	public String getZmtr_box() {
		return zmtr_box;
	}
	public void setZmtr_box(String zmtr_box) {
		this.zmtr_box = zmtr_box;
	}
	public String getZmtr_seal() {
		return zmtr_seal;
	}
	public void setZmtr_seal(String zmtr_seal) {
		this.zmtr_seal = zmtr_seal;
	}
	public String getMeter_function() {
		return meter_function;
	}
	public void setMeter_function(String meter_function) {
		this.meter_function = meter_function;
	}
	public String getZcurr_reading() {
		return zcurr_reading;
	}
	public void setZcurr_reading(String zcurr_reading) {
		this.zcurr_reading = zcurr_reading;
	}
	public String getSrv_cable_type() {
		return srv_cable_type;
	}
	public void setSrv_cable_type(String srv_cable_type) {
		this.srv_cable_type = srv_cable_type;
	}
	public String getZsrv_status() {
		return zsrv_status;
	}
	public void setZsrv_status(String zsrv_status) {
		this.zsrv_status = zsrv_status;
	}
	public String getZsrv_type_loc() {
		return zsrv_type_loc;
	}
	public void setZsrv_type_loc(String zsrv_type_loc) {
		this.zsrv_type_loc = zsrv_type_loc;
	}
	public String getMetershiftreq() {
		return metershiftreq;
	}
	public void setMetershiftreq(String metershiftreq) {
		this.metershiftreq = metershiftreq;
	}
	public String getZaddcable() {
		return zaddcable;
	}
	public void setZaddcable(String zaddcable) {
		this.zaddcable = zaddcable;
	}
	public String getZunit() {
		return zunit;
	}
	public void setZunit(String zunit) {
		this.zunit = zunit;
	}
	public String getZsrv_cable_lngh() {
		return zsrv_cable_lngh;
	}
	public void setZsrv_cable_lngh(String zsrv_cable_lngh) {
		this.zsrv_cable_lngh = zsrv_cable_lngh;
	}
	public String getJointavailstatus() {
		return jointavailstatus;
	}
	public void setJointavailstatus(String jointavailstatus) {
		this.jointavailstatus = jointavailstatus;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getZentryby() {
		return zentryby;
	}
	public void setZentryby(String zentryby) {
		this.zentryby = zentryby;
	}
	public String getZentrydate() {
		return zentrydate;
	}
	public void setZentrydate(String zentrydate) {
		this.zentrydate = zentrydate;
	}
	public String getZentrytime() {
		return zentrytime;
	}
	public void setZentrytime(String zentrytime) {
		this.zentrytime = zentrytime;
	}
	public String getZlatitude() {
		return zlatitude;
	}
	public void setZlatitude(String zlatitude) {
		this.zlatitude = zlatitude;
	}
	public String getZlongitude() {
		return zlongitude;
	}
	public void setZlongitude(String zlongitude) {
		this.zlongitude = zlongitude;
	}
	
	
	
}
