package com.riyo.endpoints;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
@Path("/Data")
public class MyDataExchanger
{
	
	@GET
    @Produces(MediaType.APPLICATION_JSON)
	@Path("/Get")
    public String getIt(@QueryParam("ivrs") @NotNull String ivrs) 
    {
    	try
    	{
    		OkHttpClient client = new OkHttpClient().newBuilder().build();
    		Request request = new Request.Builder()
    									 .url("http://115.124.119.195/mpez/secureapi/ci/view/?ivrs="+ ivrs)
    									 .method("GET",null)
    									 .addHeader("Authorization", "Basic cm1zOnJtcyMxMjMjbXBleg==")
    									 .build();
    		
    		Response response = client.newCall(request).execute();
    		return response.body().string();
		
    	} 
    	catch (Exception ex)
    	{
			return "ERROR : "+ex.getMessage();
		}
    	
    }
	
	
	@POST
	@Produces("text/plain")
	@Path("/Set")
	@Consumes(MediaType.APPLICATION_JSON)
    public String postIt(Customer cst)
    {
    	try
    	{
    		JSONObject json = new JSONObject();
    		json.put("PLANT", cst.getPlant());
    		json.put("DISTT", cst.getDistt());
    		json.put("division_id", cst.getDivision_id());
    		json.put("division_name", cst.getDivision_name());
    		json.put("DC_Code", cst.getDc_code());
    		json.put("DC_Name", cst.getDc_name());
    		json.put("Feeder_id", cst.getFeeder_id());
    		json.put("FEEDERNAME", cst.getFeedername());
    		json.put("DTR_Code", cst.getDtr_code());
    		json.put("ZDTR_NAME", cst.getZdtr_name());
    		json.put("ZCONSUMER_NO", cst.getZconsumer_no());
    		json.put("CONSUMERNAME", cst.getConsumername());
    		json.put("ZADDRESS1", cst.getZaddress1());
    		json.put("ZMOBILENO", cst.getZmobileno());
    		json.put("ZMTR_AVAIL", cst.getZmtr_avail());
    		json.put("ZMTR_NO", cst.getZmtr_no());
    		json.put("ZMTRDESC", cst.getZmtrdesc());
    		json.put("CALL_BELL_LOC", cst.getCall_bell_loc());
    		json.put("ZMTR_TYPE", cst.getZmtr_type());
    		json.put("MANUFACTURENAME", cst.getManufacturename());
    		json.put("ZMANYEAR", cst.getZmanyear());
    		json.put("ZMTR_BOX", cst.getZmtr_box());
    		json.put("ZMTR_SEAL", cst.getZmtr_seal());
    		json.put("METER_FUNCTION", cst.getMeter_function());
    		json.put("ZCURR_READING", cst.getZcurr_reading());
    		json.put("SRV_CABLE_TYPE", cst.getSrv_cable_type());
    		json.put("ZSRV_STATUS", cst.getZsrv_status());
    		json.put("ZSRV_TYPE_LOC", cst.getZsrv_type_loc());
    		json.put("METERSHIFTREQ", cst.getMetershiftreq());
    		json.put("ZADDCABLE", cst.getZaddcable());
    		json.put("ZUNIT", cst.getZunit());
    		json.put("ZSRV_CABLE_LNGH", cst.getZsrv_cable_lngh());
    		json.put("JOINTAVAILSTATUS", cst.getJointavailstatus());
    		json.put("EMPNAME", cst.getEmpname());
    		json.put("ZENTRYBY", cst.getZentryby());
    		json.put("ZENTRYDATE", cst.getZentrydate());
    		json.put("ZENTRYTIME", cst.getZentrytime());
    		json.put("ZLATITUDE" , cst.getZlatitude());
    		json.put("ZLONGITUDE", cst.getZlongitude());
    		
    		OkHttpClient client = new OkHttpClient().newBuilder().build();
    		okhttp3.MediaType JSON = okhttp3.MediaType.parse("application/json; charset=utf-8");
    		
    		
    		@SuppressWarnings("deprecation")
			RequestBody body = RequestBody.create(JSON, json.toString());
    		
    		Request request = new Request.Builder()
    									 .url("http://115.124.119.195/mpez/secureapi/ci/insert/")
    									 .method("POST",body)
    									 .addHeader("Authorization", "Basic cm1zOnJtcyMxMjMjbXBleg==")
    									 .build();
    		
    		Response response = client.newCall(request).execute();
    		
    		if(response.isSuccessful())
    		{
    			return "Data inserted successfully." + response.message();
    		}
    		else
    		{
    			return "Data not inserted." + response.message();
    		}
 
		
    	} 
    	catch (Exception ex)
    	{
			return "ERROR : "+ex.getMessage();
		}
    	
    }

}
