package com.YPSoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JbpElectricApplication {

	public static void main(String[] args) {
		SpringApplication.run(JbpElectricApplication.class, args);
	}

}
