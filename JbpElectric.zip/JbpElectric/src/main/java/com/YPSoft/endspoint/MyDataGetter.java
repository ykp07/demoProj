package com.YPSoft.endspoint;

import org.json.JSONObject;
import org.springframework.stereotype.Service;


import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
@Path("/Data")
public class MyDataGetter 
{
	@GET
    @Produces(MediaType.APPLICATION_JSON)
	@Path("/Get")
    public String getIt(@QueryParam("ivrs") @NotNull String ivrs) 
    {
    	try
    	{
    		OkHttpClient client = new OkHttpClient().newBuilder().build();
    		Request request = new Request.Builder()
    									 .url("http://115.124.119.195/mpez/secureapi/ci/view/?ivrs="+ ivrs)
    									 .method("GET",null)
    									 .addHeader("Authorization", "Basic cm1zOnJtcyMxMjMjbXBleg==")
    									 .build();
    		
    		Response response = client.newCall(request).execute();
    		return response.body().string();
		
    	} 
    	catch (Exception ex)
    	{
			return "ERROR : "+ex.getMessage();
		}
    	
    }
	
	
	@POST
	@Produces("text/plain")
	@Path("/Set")
	@Consumes(MediaType.APPLICATION_JSON)
    public String postIt(Customer cst)
    {
    	try
    	{
    		JSONObject json = new JSONObject();
    		json.put("PLANT", cst.getPlant());
    		json.put("DISTT", cst.getDistt());
    		json.put("division_id", cst.getDivision_id());
    		json.put("division_name", cst.getDivision_name());
    		json.put("DC_Code", cst.getDc_code());
    		json.put("DC_Name", cst.getDc_name());
    		json.put("Feeder_id", cst.getFeeder_id());
    		json.put("FEEDERNAME", cst.getFeedername());
    		json.put("DTR_Code", cst.getDtr_code());
    		json.put("ZDTR_NAME", cst.getZdtr_name());
    		json.put("ZCONSUMER_NO", cst.getZconsumer_no());
    		json.put("CONSUMERNAME", cst.getConsumername());
    		json.put("ZADDRESS1", cst.getZaddress1());
    		json.put("ZMOBILENO", cst.getZmobileno());
    		json.put("ZMTR_AVAIL", cst.getZmtr_avail());
    		json.put("ZMTR_NO", cst.getZmtr_no());
    		json.put("ZMTRDESC", cst.getZmtrdesc());
    		json.put("CALL_BELL_LOC", cst.getCall_bell_loc());
    		json.put("ZMTR_TYPE", cst.getZmtr_type());
    		json.put("MANUFACTURENAME", cst.getManufacturename());
    		json.put("ZMANYEAR", cst.getZmanyear());
    		json.put("ZMTR_BOX", cst.getZmtr_box());
    		json.put("ZMTR_SEAL", cst.getZmtr_seal());
    		json.put("METER_FUNCTION", cst.getMeter_function());
    		json.put("ZCURR_READING", cst.getZcurr_reading());
    		json.put("SRV_CABLE_TYPE", cst.getSrv_cable_type());
    		json.put("ZSRV_STATUS", cst.getZsrv_status());
    		json.put("ZSRV_TYPE_LOC", cst.getZsrv_type_loc());
    		json.put("METERSHIFTREQ", cst.getMetershiftreq());
    		json.put("ZADDCABLE", cst.getZaddcable());
    		json.put("ZUNIT", cst.getZunit());
    		json.put("ZSRV_CABLE_LNGH", cst.getZsrv_cable_lngh());
    		json.put("JOINTAVAILSTATUS", cst.getJointavailstatus());
    		json.put("EMPNAME", cst.getEmpname());
    		json.put("ZENTRYBY", cst.getZentryby());
    		json.put("ZENTRYDATE", cst.getZentrydate());
    		json.put("ZENTRYTIME", cst.getZentrytime());
    		json.put("ZLATITUDE" , cst.getZlatitude());
    		json.put("ZLONGITUDE", cst.getZlongitude());
    		
    		OkHttpClient client = new OkHttpClient().newBuilder().build();
    		okhttp3.MediaType JSON = okhttp3.MediaType.parse("application/json; charset=utf-8");
    		
    		RequestBody body = RequestBody.create(JSON, json.toString());
    		
    		Request request = new Request.Builder()
    									 .url("http://115.124.119.195/mpez/secureapi/ci/insert/")
    									 .method("POST",body)
    									 .addHeader("Authorization", "Basic cm1zOnJtcyMxMjMjbXBleg==")
    									 .build();
    		
    		Response response = client.newCall(request).execute();
    		
    		if(response.isSuccessful())
    		{
    			return "Data inserted successfully." + response.message();
    		}
    		else
    		{
    			return "Data not inserted." + response.message();
    		}
 
		
    	} 
    	catch (Exception ex)
    	{
			return "ERROR : "+ex.getMessage();
		}
    	
    }
	
	
//	@POST
//	@Produces("text/plain")
//	@Path("/Set")
//	@Consumes(MediaType.APPLICATION_JSON)
//    public String postIt(
//			@FormParam("PLANT") String PLANT,
//    		@FormParam("DISTT") String DISTT,
//    		@FormParam("division_id") String division_id,
//    		@FormParam("division_name") String division_name,
//    		@FormParam("DC_Code") String DC_Code,
//    		@FormParam("DC_Name") String DC_Name,
//    		@FormParam("Feeder_id") String Feeder_id,
//    		@FormParam("FEEDERNAME") String FEEDERNAME,
//    		@FormParam("DTR_Code") String DTR_Code,
//    		@FormParam("ZDTR_NAME") String ZDTR_NAME,
//    		@FormParam("ZCONSUMER_NO") String ZCONSUMER_NO,
//    		@FormParam("CONSUMERNAME") String CONSUMERNAME,
//    		@FormParam("ZADDRESS1") String ZADDRESS1,
//    		@FormParam("ZMOBILENO") String ZMOBILENO,
//    		@FormParam("ZMTR_AVAIL") String ZMTR_AVAIL,
//    		@FormParam("ZMTR_NO") String ZMTR_NO,
//    		@FormParam("ZMTRDESC") String ZMTRDESC,
//    		@FormParam("CALL_BELL_LOC") String CALL_BELL_LOC,
//    		@FormParam("ZMTR_TYPE") String ZMTR_TYPE,
//    		@FormParam("MANUFACTURENAME") String MANUFACTURENAME,
//    		@FormParam("ZMANYEAR") String ZMANYEAR,
//    		@FormParam("ZMTR_BOX") String ZMTR_BOX,
//    		@FormParam("ZMTR_SEAL") String ZMTR_SEAL,
//    		@FormParam("METER_FUNCTION") String METER_FUNCTION,
//    		@FormParam("ZCURR_READING") String ZCURR_READING,
//    		@FormParam("SRV_CABLE_TYPE") String SRV_CABLE_TYPE,
//    		@FormParam("ZSRV_STATUS") String ZSRV_STATUS,
//    		@FormParam("ZSRV_TYPE_LOC") String ZSRV_TYPE_LOC,
//    		@FormParam("METERSHIFTREQ") String METERSHIFTREQ,
//    		@FormParam("ZADDCABLE") String ZADDCABLE,
//    		@FormParam("ZUNIT") String ZUNIT,
//    		@FormParam("ZSRV_CABLE_LNGH") String ZSRV_CABLE_LNGH,
//    		@FormParam("JOINTAVAILSTATUS") String JOINTAVAILSTATUS,
//    		@FormParam("EMPNAME") String EMPNAME,
//    		@FormParam("ZENTRYBY") String ZENTRYBY,
//    		@FormParam("ZENTRYDATE") String ZENTRYDATE,
//    		@FormParam("ZENTRYTIME") String ZENTRYTIME,
//    		@FormParam("ZLATITUDE" ) String ZLATITUDE,
//    		@FormParam("ZLONGITUDE") String ZLONGITUDE
//    		
//    )
//    {
//    	try
//    	{
//    		JSONObject json = new JSONObject();
//    		json.put("PLANT", PLANT);
//    		json.put("DISTT", DISTT);
//    		json.put("division_id", division_id);
//    		json.put("division_name", division_name);
//    		json.put("DC_Code", DC_Code);
//    		json.put("DC_Name", DC_Name);
//    		json.put("Feeder_id", Feeder_id);
//    		json.put("FEEDERNAME", FEEDERNAME);
//    		json.put("DTR Code", DTR_Code);
//    		json.put("ZDTR_NAME", ZDTR_NAME);
//    		json.put("ZCONSUMER_NO", ZCONSUMER_NO);
//    		json.put("CONSUMERNAME", CONSUMERNAME);
//    		json.put("ZADDRESS1", ZADDRESS1);
//    		json.put("ZMOBILENO", ZMOBILENO);
//    		json.put("ZMTR_AVAIL", ZMTR_AVAIL);
//    		json.put("ZMTR_NO", ZMTR_NO);
//    		json.put("ZMTRDESC", ZMTRDESC);
//    		json.put("CALL_BELL_LOC", CALL_BELL_LOC);
//    		json.put("ZMTR_TYPE", ZMTR_TYPE);
//    		json.put("MANUFACTURENAME", MANUFACTURENAME);
//    		json.put("ZMANYEAR", ZMANYEAR);
//    		json.put("ZMTR_BOX", ZMTR_BOX);
//    		json.put("ZMTR_SEAL", ZMTR_SEAL);
//    		json.put("METER_FUNCTION", METER_FUNCTION);
//    		json.put("ZCURR_READING", ZCURR_READING);
//    		json.put("SRV_CABLE_TYPE", SRV_CABLE_TYPE);
//    		json.put("ZSRV_STATUS", ZSRV_STATUS);
//    		json.put("ZSRV_TYPE_LOC", ZSRV_TYPE_LOC);
//    		json.put("METERSHIFTREQ", METERSHIFTREQ);
//    		json.put("ZADDCABLE", ZADDCABLE);
//    		json.put("ZUNIT", ZUNIT);
//    		json.put("ZSRV_CABLE_LNGH", ZSRV_CABLE_LNGH);
//    		json.put("JOINTAVAILSTATUS", JOINTAVAILSTATUS);
//    		json.put("EMPNAME", EMPNAME);
//    		json.put("ZENTRYBY", ZENTRYBY);
//    		json.put("ZENTRYDATE", ZENTRYDATE);
//    		json.put("ZENTRYTIME", ZENTRYTIME);
//    		json.put("ZLATITUDE" , ZLATITUDE);
//    		json.put("ZLONGITUDE", ZLONGITUDE);
//    		
//    		
//    		OkHttpClient client = new OkHttpClient().newBuilder().build();
//    		okhttp3.MediaType JSON = okhttp3.MediaType.parse("application/json; charset=utf-8");
//    		
//    		RequestBody body = RequestBody.create(JSON, json.toString());
//    		
//    		Request request = new Request.Builder()
//    									 .url("http://115.124.119.195/mpez/secureapi/ci/insert/")
//    									 .method("POST",body)
//    									 .addHeader("Authorization", "Basic cm1zOnJtcyMxMjMjbXBleg==")
//    									 .build();
//    		
//    		Response response = client.newCall(request).execute();
//    		
//    		if(response.isSuccessful())
//    		{
//    			return "Data inserted successfully." + response.message();
//    		}
//    		else
//    		{
//    			return "Data not inserted." + response.message();
//    		}
// 
//		
//    	} 
//    	catch (Exception ex)
//    	{
//			return "ERROR : "+ex.getMessage();
//		}
//    	
//    }

}
