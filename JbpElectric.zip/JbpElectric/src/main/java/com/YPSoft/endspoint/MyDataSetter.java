package com.YPSoft.endspoint;

import org.springframework.stereotype.Service;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.RequestBody;

import org.json.*;

@Service
@Path("/SetData")
public class MyDataSetter
{
	@POST
	@Produces("text/plain")
    public String postIt(
			@FormParam("PLANT") @NotNull String PLANT,
    		@FormParam("DISTT") @NotNull String DISTT,
    		@FormParam("division_id") @NotNull String division_id,
    		@FormParam("division_name") @NotNull String division_name,
    		@FormParam("DC_Code") @NotNull String DC_Code,
    		@FormParam("DC_Name") @NotNull String DC_Name,
    		@FormParam("Feeder_id") @NotNull String Feeder_id,
    		@FormParam("FEEDERNAME") @NotNull String FEEDERNAME,
    		@FormParam("DTR_Code") @NotNull String DTR_Code,
    		@FormParam("ZDTR_NAME") @NotNull String ZDTR_NAME,
    		@FormParam("ZCONSUMER_NO") @NotNull String ZCONSUMER_NO,
    		@FormParam("CONSUMERNAME") @NotNull String CONSUMERNAME,
    		@FormParam("ZADDRESS1") @NotNull String ZADDRESS1,
    		@FormParam("ZMOBILENO") @NotNull String ZMOBILENO,
    		@FormParam("ZMTR_AVAIL") @NotNull String ZMTR_AVAIL,
    		@FormParam("ZMTR_NO") @NotNull String ZMTR_NO,
    		@FormParam("ZMTRDESC") @NotNull String ZMTRDESC,
    		@FormParam("CALL_BELL_LOC") @NotNull String CALL_BELL_LOC,
    		@FormParam("ZMTR_TYPE") @NotNull String ZMTR_TYPE,
    		@FormParam("MANUFACTURENAME") @NotNull String MANUFACTURENAME,
    		@FormParam("ZMANYEAR") @NotNull String ZMANYEAR,
    		@FormParam("ZMTR_BOX") @NotNull String ZMTR_BOX,
    		@FormParam("ZMTR_SEAL") @NotNull String ZMTR_SEAL,
    		@FormParam("METER_FUNCTION") @NotNull String METER_FUNCTION,
    		@FormParam("ZCURR_READING") @NotNull String ZCURR_READING,
    		@FormParam("SRV_CABLE_TYPE") @NotNull String SRV_CABLE_TYPE,
    		@FormParam("ZSRV_STATUS") @NotNull String ZSRV_STATUS,
    		@FormParam("ZSRV_TYPE_LOC") @NotNull String ZSRV_TYPE_LOC,
    		@FormParam("METERSHIFTREQ") @NotNull String METERSHIFTREQ,
    		@FormParam("ZADDCABLE") @NotNull String ZADDCABLE,
    		@FormParam("ZUNIT") @NotNull String ZUNIT,
    		@FormParam("ZSRV_CABLE_LNGH") @NotNull String ZSRV_CABLE_LNGH,
    		@FormParam("JOINTAVAILSTATUS") @NotNull String JOINTAVAILSTATUS,
    		@FormParam("EMPNAME") @NotNull String EMPNAME,
    		@FormParam("ZENTRYBY") @NotNull String ZENTRYBY,
    		@FormParam("ZENTRYDATE") @NotNull String ZENTRYDATE,
    		@FormParam("ZENTRYTIME") @NotNull String ZENTRYTIME,
    		@FormParam("ZLATITUDE" ) @NotNull String ZLATITUDE,
    		@FormParam("ZLONGITUDE") @NotNull String ZLONGITUDE
    		
    )
    {
    	try
    	{
    		JSONObject json = new JSONObject();
    		json.put("PLANT", PLANT);
    		json.put("DISTT", DISTT);
    		json.put("division_id", division_id);
    		json.put("division_name", division_name);
    		json.put("DC_Code", DC_Code);
    		json.put("DC_Name", DC_Name);
    		json.put("Feeder_id", Feeder_id);
    		json.put("FEEDERNAME", FEEDERNAME);
    		json.put("DTR Code", DTR_Code);
    		json.put("ZDTR_NAME", ZDTR_NAME);
    		json.put("ZCONSUMER_NO", ZCONSUMER_NO);
    		json.put("CONSUMERNAME", CONSUMERNAME);
    		json.put("ZADDRESS1", ZADDRESS1);
    		json.put("ZMOBILENO", ZMOBILENO);
    		json.put("ZMTR_AVAIL", ZMTR_AVAIL);
    		json.put("ZMTR_NO", ZMTR_NO);
    		json.put("ZMTRDESC", ZMTRDESC);
    		json.put("CALL_BELL_LOC", CALL_BELL_LOC);
    		json.put("ZMTR_TYPE", ZMTR_TYPE);
    		json.put("MANUFACTURENAME", MANUFACTURENAME);
    		json.put("ZMANYEAR", ZMANYEAR);
    		json.put("ZMTR_BOX", ZMTR_BOX);
    		json.put("ZMTR_SEAL", ZMTR_SEAL);
    		json.put("METER_FUNCTION", METER_FUNCTION);
    		json.put("ZCURR_READING", ZCURR_READING);
    		json.put("SRV_CABLE_TYPE", SRV_CABLE_TYPE);
    		json.put("ZSRV_STATUS", ZSRV_STATUS);
    		json.put("ZSRV_TYPE_LOC", ZSRV_TYPE_LOC);
    		json.put("METERSHIFTREQ", METERSHIFTREQ);
    		json.put("ZADDCABLE", ZADDCABLE);
    		json.put("ZUNIT", ZUNIT);
    		json.put("ZSRV_CABLE_LNGH", ZSRV_CABLE_LNGH);
    		json.put("JOINTAVAILSTATUS", JOINTAVAILSTATUS);
    		json.put("EMPNAME", EMPNAME);
    		json.put("ZENTRYBY", ZENTRYBY);
    		json.put("ZENTRYDATE", ZENTRYDATE);
    		json.put("ZENTRYTIME", ZENTRYTIME);
    		json.put("ZLATITUDE" , ZLATITUDE);
    		json.put("ZLONGITUDE", ZLONGITUDE);
    		
    		
    		OkHttpClient client = new OkHttpClient().newBuilder().build();
    		okhttp3.MediaType JSON = okhttp3.MediaType.parse("application/json; charset=utf-8");
    		
    		RequestBody body = RequestBody.create(JSON, json.toString());
    		
    		Request request = new Request.Builder()
    									 .url("http://115.124.119.195/mpez/secureapi/ci/insert/")
    									 .method("POST",body)
    									 .addHeader("Authorization", "Basic cm1zOnJtcyMxMjMjbXBleg==")
    									 .build();
    		
    		Response response = client.newCall(request).execute();
    		
    		if(response.isSuccessful())
    		{
    			return "Data inserted successfully.";
    		}
    		else
    		{
    			return "Data not inserted.";
    		}
 
		
    	} 
    	catch (Exception ex)
    	{
			return "ERROR : "+ex.getMessage();
		}
    	
    }
    
}
